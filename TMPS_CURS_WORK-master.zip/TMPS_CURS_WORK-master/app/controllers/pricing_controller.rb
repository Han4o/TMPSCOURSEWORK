class PricingController < ApplicationController
  layout "subscribe"

  def index
  end
end